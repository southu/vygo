# Guide changelog

Tracks **this documentation pack** (`docs/ratchet-guide/v1.2/`), not the Ratchet software itself.

**Why it exists:** when you re-share the folder with friends or drop it on a new host, they can see what changed without diffing every file. Software/ops changes on a private host still belong in a private `docs/operator/CHANGELOG.md` (not this pack).

Pack folders: **`v1.2`** (current) · **`v1.1`** (archive). Section labels below remain `guide-YYYY-MM-DD` plus pack version.

---

## v1.2 / guide-2026-07-17f — strip operator procedures

### Removed

- Production deploy/host troubleshooting tables and queue-recovery procedures from [`footguns.md`](./footguns.md)
- Deploy-timeout diagnostic prompt from [`ai-prompts.md`](./ai-prompts.md)
- Cloud token / vault failure-mode runbooks and process-manager operational recipes across vault, rebuild, projects-and-deploy, operations
- Runtime service administration steps that read as host ops rather than product architecture

### Changed

- [`footguns.md`](./footguns.md) reframed as design pitfalls (contracts and boundaries)
- [`vault.md`](./vault.md), [`operations.md`](./operations.md), [`rebuild.md`](./rebuild.md), [`lazy-medic-sentinel.md`](./lazy-medic-sentinel.md) kept as product-level roles and shapes only
- [`ai-prompts.md`](./ai-prompts.md) reduced to rebuild / new-product / friend-share prompts
- One-pager print HTML aligned with sanitized non-negotiables

### Not published

- Host-private ops runbooks, vault administration procedures, and cloud provisioning playbooks remain out of this share pack

---

## v1.2 / guide-2026-07-17e — public ops sanitization

### Removed

- Production SSH, heal-tick, and long-lived night-watch babysit prompts from [`ai-prompts.md`](./ai-prompts.md)
- Day-to-day process-manager command recipes, heal-timer runbooks, SSH deploy snippets, and browser-console instructions from [`operations.md`](./operations.md)
- Night-watch poll-cadence diagrams and mental-model links across overview, architecture, principles, rebuild, diagrams, lazy-medic, one-pager

### Changed

- Replaced absolute server-style path roots with placeholder **`RATCHET_ROOT/{control,harness,projects}`**
- [`operations.md`](./operations.md) retitled to runtime-services overview (product-level architecture only)
- Fixed broken pack-external root-pointer link (404 on the public site); historical root pointer is outside this pack and not published

### Not published

- Host-private ops runbooks remain out of this share pack

---

## v1.2 / guide-2026-07-17d — one-pager clean-URL rename

### Changed

- Renamed the printable HTML one-pager: file `one-pager.html` → `one-pager-print.html`, published and linked as [`one-pager-print`](./one-pager-print). The pack host serves the site with Vercel `cleanUrls`, which 308-redirects every `.html` URL to its extensionless form — listing and linking the extensionless clean URL makes the printable sheet return 200 directly.

---

## v1.2 / guide-2026-07-17c — web-publication sanitization

### Added

- [`one-pager-print`](./one-pager-print) staged next to [`one-pager.md`](./one-pager.md): same single-sheet content, self-contained (inline SVG, `@media print`, letter) so the published link works with no external assets

### Changed

- Replaced third-party service domains in examples with unmistakable placeholders (`git.example.com`, `cloud.example.com`)
- Removed host-specific scratch paths (null-device output sinks, relative rsync sources) from command examples — every remaining filesystem path is an illustrative install root

---

## v1.2 / guide-2026-07-17b — public path names

### Changed

- Replaced production-style absolute path roots with neutral **`RATCHET_ROOT/{control,harness,projects}`** placeholders across the pack so the guide can be published without fingerprinting a real host layout
- Clarified that those paths are **illustrative** only

---

## v1.2 / guide-2026-07-17 — product behavior + versioned packs

### Added

- Versioned layout under `docs/ratchet-guide/`: `v1.1/` archive, `v1.2/` current
- Documented **~4–8 step** planner depth and thin-draft resplit
- Documented queue clear **All (keep running)** keeps draft steps
- Documented vault **custom arm hours**, **8h shortcut**, and **arm persistence** across consumer restart
- Assist/model footguns: Kimi in assist registry, CLI flag mismatches, real errors vs synthetic prose

### Changed

- [`composer.md`](./composer.md) — queue builder rules, clear modes, models
- [`vault.md`](./vault.md) — arm duration + persistence
- [`operations.md`](./operations.md) — vault unlock vs re-arm notes
- [`loop-and-missions.md`](./loop-and-missions.md) — multi-step campaign note
- [`footguns.md`](./footguns.md) — new queue / vault / model rows
- [`README.md`](./README.md), [`one-pager.md`](./one-pager.md) — pack version pointers

### Not in this pack (parked product work)

- Draft list double-numbering UI fix
- Model effort selection UI

---

## guide-2026-07-15c — night-watch cadence (later removed from public pack)

### Added

- Documented long-lived night-watch poll cadence for install operators (later removed in guide-2026-07-17e as host-private ops material)

### Changed

- Cross-links in overview / architecture / operations for the (now-removed) cadence notes

---

## guide-2026-07-15b — diagrams, one-pager, changelog

### Added

- [`diagrams.md`](./diagrams.md) — Mermaid gallery (happy path, edge, trust, loop state, ops vs product, Vault sequence, rebuild phases)
- [`one-pager.md`](./one-pager.md) — single-sheet Markdown summary
- [`one-pager-print`](./one-pager-print) — print/PDF-friendly HTML (letter, @media print, self-contained inline SVG)
- This file (`CHANGELOG.md`)

### Changed

- [`README.md`](./README.md) — links to diagrams, one-pager, changelog
- [`overview.md`](./overview.md) — Mermaid happy-path diagram
- [`architecture.md`](./architecture.md) — Mermaid system map + data-flow diagram
- [`loop-and-missions.md`](./loop-and-missions.md) — Mermaid iteration state diagram
- Root pointer file (outside this pack; not published) — points at one-pager + diagrams

---

## guide-2026-07-15a — multi-file pack split

### Added

- Full pack split from a single-file root pointer into:
  - overview, architecture, principles, layout
  - loop-and-missions, composer, lazy-medic-sentinel, vault
  - projects-and-deploy, operations, rebuild, ai-prompts
  - footguns, examples, README index
- Expanded failure-mode lessons (worker survival, Railway dedupe, Vercel author, version auth, queue multi-step)
- Paste-ready AI prompts (rebuild / deploy-timeout / new product)

### Changed

- Root pointer outside this pack became a short pointer to `docs/ratchet-guide/`

---

## How to bump

When you edit the guide meaningfully:

1. Add a dated section at the **top** of this file
2. List Added / Changed / Removed
3. Optionally tag the share zip `ratchet-guide-YYYY-MM-DD`

Keep entries short; link to files instead of pasting whole docs.
